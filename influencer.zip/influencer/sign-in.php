<!DOCTYPE html>
<html class="no-js" lang="ZXX">
	
<!-- Mirrored from quomodothemes.website/html/inflanar/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2024 11:49:00 GMT -->
<head>
		<!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="#">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Site Title -->
		<title>Influencer Connect</title>
		
		<!-- Fav Icon -->
		<link rel="icon" href="img/favicon.ico">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,400;1,500;1,700&amp;display=swap" rel="stylesheet"> 

		<!-- Bootstrap -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Jquery UI CSS -->
		<link rel="stylesheet" href="css/jquery-ui.min.css">
		<!-- Animate CSS -->
		<link rel="stylesheet" href="css/animate.min.css">
		<!-- AOS CSS -->
		<link rel="stylesheet" href="css/aos.min.css">
		<!-- Fontawesome -->
		<link rel="stylesheet" href="css/font-awesome-all.min.css">
		<!-- Swiper Slider CSS -->
		<link rel="stylesheet" href="css/swiper-slider.min.css">
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="css/select2-min.css">
		<!-- Data Tables -->
		<link rel="stylesheet" href="css/datatables.min.css">
		<!-- Video Popup -->
		<link rel="stylesheet" href="css/video-popup.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="css/theme-default.css">
		<link rel="stylesheet" href="style.css">
		
	</head>

	<body>
		<div id="loading">
			<div id="loading-center">
			   <div id="loading-center-absolute">
				  <div class="object" id="object_one"></div>
				  <div class="object" id="object_two"></div>
				  <div class="object" id="object_three"></div>
				  <div class="object" id="object_four"></div>
				  <div class="object" id="object_five"></div>
			   </div>
			</div>  
		 </div>
		<!-- End Preloader -->
		
		<!-- Sign In -->
        <section class="inflanar-signin pd-top-120 pd-btm-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="inflanar-signin__body">
                            <div class="row">
                                <div class="col-lg-6 col-12">
									<div class="inflanar-signin__logins">
										<!-- Login header -->
										<div class="inflanar-signin__header mg-btm-10">
											<div class="inflanar-signin__heading">
												<h4 class="inflanar-signin__title">Login</h4>
												<p class="inflanar-signin__tag">Welcome to Infuencer Connect</p>
											</div>
											<div class="inflanar-signin__heading__options">
												<!--Tab Nav -->
												<div class="list-group inflanar-signin__options" id="list-tab" role="tablist">
													<a class="list-group-item active" data-bs-toggle="list" href="#in-tab9" role="tab">
														<span>Client</span>
													</a>
													<a class="list-group-item" data-bs-toggle="list" href="#in-tab10" role="tab">
														<span>Influencer</span>
													</a>
												</div>
											</div>
										</div> 
										<!-- End Login header -->

										<div class="tab-content mg-top-30" id="nav-tabContent">
											<!-- Single Tab -->
											<div class="tab-pane fade active show" id="in-tab9" role="tabpanel">
												<div class="inflanar-signin__inner">
													<form action="#">
														<div class="row">
															<div class="col-12">
																<div class="form-group inflanar-form-input mg-top-20">
																	<label>Email*</label>
																	<input class="ecom-wc__form-input" type="email" name="f_name" placeholder="infoyour@gmail.com" required="required">
																</div>
																<div class="form-group inflanar-form-input mg-top-20">
																	<label>Password*</label>
																	<input class="inflanar-signin__form-input" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" id="password-field" type="password" name="password" maxlength="8" required="required">
																</div>
																<div class="form-group mg-top-20">
																	<div class="inflanar-signin__check-inline">
																		<div class="inflanar-signin__checkbox">
																			<div class="inflanar-signin__checkbox--group">
																				<input class="inflanar-signin__form-check" id="checkbox" name="checkbox" type="checkbox">
																				<label for="checkbox">Remember Me</label>
																			</div>
																		</div>
																		<div class="inflanar-signin__forgot">
																			<a href="forgot-password.html" class="forgot-pass">Forgot Password?</a>
																		</div>
																	</div>
																</div>
																<!-- Login Button Group -->
																<div class="form-group mg-top-40">
																	<button type="submit" class="inflanar-btn"><span>Log In</span></button>
																</div>
																<div class="inflanar-signin__bottom">
																	<!--<div class="inflanar-signin__form-login--label"><span>OR</span></div>-->
																	<!-- Login Button Group -->
																	<!--<div class="inflanar-signin__button--group">
																		<button class="inflanar-btn inflanar-btn__other" type="submit"><div class="inflanar-signin__btn-icon"><img src="img/in-google-logo.png"></div>Sign In with Google</button>
																		<button class="inflanar-btn inflanar-btn__other" type="submit"><div class="inflanar-signin__btn-icon"><img src="img/in-facebook-logo.png"></div>Sign In with Facebook</button>
																	</div>-->
																	<p class="inflanar-signin__text mg-top-20">Dont’t have an aceount ?  <a href="register.html">Create Account</a></p>
																</div>
															</div>
														</div>
													</form>
												</div>
											</div>
											<!-- End Single Tab -->
											<!-- Single Tab -->
											<div class="tab-pane fade" id="in-tab10" role="tabpanel">
												<div class="inflanar-signin__inner">
													<form action="#">
														<div class="row">
															<div class="col-12">
																<div class="form-group inflanar-form-input mg-top-20">
																	<label>Email*</label>
																	<input class="ecom-wc__form-input" type="email" name="f_name" placeholder="infoyour@gmail.com" required="required">
																</div>
																<div class="form-group inflanar-form-input mg-top-20">
																	<label>Password*</label>
																	<input class="inflanar-signin__form-input" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" id="password-field" type="password" name="password" maxlength="8" required="required">
																</div>
																<div class="form-group mg-top-20">
																	<div class="inflanar-signin__check-inline">
																		<div class="inflanar-signin__checkbox">
																			<div class="inflanar-signin__checkbox--group">
																				<input class="inflanar-signin__form-check" id="checkbox2" name="checkbox2" type="checkbox">
																				<label for="checkbox2">Remember Me</label>
																			</div>
																		</div>
																		<div class="inflanar-signin__forgot">
																			<a href="forgot-password.html" class="forgot-pass">Forgot Password?</a>
																		</div>
																	</div>
																</div>
																<!-- Login Button Group -->
																<div class="form-group mg-top-40">
																	<button type="submit" class="inflanar-btn"><span>Log In</span></button>
																</div>
																<div class="inflanar-signin__bottom">
																	<!--<div class="inflanar-signin__form-login--label"><span>OR</span></div>-->
																	<!-- Login Button Group -->
																	<!--<div class="inflanar-signin__button--group">
																		<button class="inflanar-btn inflanar-btn__other" type="submit"><div class="inflanar-signin__btn-icon"><img src="img/in-google-logo.png"></div>Sign In with Google</button>
																		<button class="inflanar-btn inflanar-btn__other" type="submit"><div class="inflanar-signin__btn-icon"><img src="img/in-facebook-logo.png"></div>Sign In with Facebook</button>
																	</div>-->
																	<p class="inflanar-signin__text mg-top-20">Dont’t have an aceount ?  <a href="register.html">Create Account</a></p>
																</div>
															</div>
														</div>
													</form>
												</div>
											</div>
											<!-- End Single Tab -->
										</div>
                               		</div>
								</div>
                                <div class="col-lg-6 col-12 d-none d-lg-block">
                                    <div class="inflanar-signin__welcome inflanar-bg-cover inflanar-section-shape18">
                                        <img src="img/in-account-cover.png" alt="#">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Sign In -->

		<!-- Footer CTA -->
		<section  class="footer-cta inflanar-bg-cover section-padding">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="footer-cta__inner inflanar-bg-cover  inflanar-section-shape3">
							<div class="footer-cta__content">
								<h3 class="footer-cta__title">Let influencers do the heavy lifting for your marketing campaign</h3>
								<a href="#" class="inflanar-btn inflanar-btn__big"><span>Signup Now!</span></a>
							</div>
							<div class="footer-cta__img">
								<img src="img/in-footer-cta.png">
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Footer CTA -->

		<?php include'footer.php'; ?>

		<!-- Scrool Top -->
		<a href="#" class="scrollToTop"><img src="img/in-scroll-up.svg"></a>
		
		<!-- Jquery JS -->
		<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery.min.js"></script>
		<script src="js/jquery-migrate.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Aos JS -->
		<script src="js/aos.min.js"></script>
		<!-- CK Editor JS -->
		<script src="js/ckeditor.min.js"></script>
		<!-- Full Calendar JS -->
		<script src="js/fullcalendar.min.js"></script>
		<!-- Select2 JS-->
		<script src="js/select2-js.min.js"></script>
		<!-- Video Popup JS -->
		<script src="js/video-popup.min.js"></script>
		<!-- Swiper SLider JS -->
		<script src="js/swiper-slider.min.js"></script>
		<!-- Waypoints JS -->
		<script src="js/waypoints.min.js"></script>
		<!-- Counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Main JS -->
		<script src="js/active.js"></script>

		<script>
			document.addEventListener('DOMContentLoaded', function() {
				var calendarEl = document.getElementById('inflanar-calender');
				var calendar = new FullCalendar.Calendar(calendarEl, {
					defaultView: 'timeGridWeek',
					contentHeight: 'auto',
					height: '100%',
					fixedWeekCount: false,
					showNonCurrentDates: true,
					columnHeaderFormat: {
					week: 'ddd'
					}
				});
				calendar.render();
			});
		 </script>
		 <script>
			ClassicEditor
				.create( document.querySelector( '#ckdesc1' ) )
				.catch( error => {
					console.error( error );
				} );
		 </script>
         <script>
			/* Testimonial Slider */
			var swiper = new Swiper(".inflanar-slider-testimonial", {
				autoplay: { 
					 delay: 3333500,
				},
				mousewheel: true,
				keyboard: true,
				loop: true,
				grabCursor: true,
				spaceBetween: 30,
				centeredSlides: false,
				pagination: {
					el: '.swiper-pagination__testimonial',
					type: 'bullets',
					clickable: true,
				},
				breakpoints: {
				  320: {
					slidesPerView: "1",
				  },
				  428: {
					slidesPerView:"1",
				  },
				  768: {
					slidesPerView:"1",
				  },
				  1024: {
					slidesPerView:"2",
				  },
				},
			});	

		</script>
		
	</body>

<!-- Mirrored from quomodothemes.website/html/inflanar/sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2024 11:49:03 GMT -->
</html>